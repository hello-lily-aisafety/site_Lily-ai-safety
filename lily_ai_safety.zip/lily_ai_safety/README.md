# LILY AI Safety Alliance — Site Institucional

Site desenvolvido com Flask (Python) e hospedado no PythonAnywhere.

## Estrutura do projeto

```
lily_ai_safety/
├── app.py                  # aplicação Flask (rotas)
├── requirements.txt        # dependências Python
├── templates/
│   ├── base.html           # layout base (navbar + footer)
│   ├── index.html          # página inicial
│   ├── sobre.html          # sobre o grupo
│   ├── membros.html        # membros
│   └── contato.html        # contato
└── static/
    └── css/
        └── style.css       # estilos
```

## Como rodar localmente

1. Instale o Python 3 e crie um ambiente virtual:
```bash
python -m venv venv
source venv/bin/activate   # Linux/Mac
venv\Scripts\activate      # Windows
```

2. Instale as dependências:
```bash
pip install -r requirements.txt
```

3. Rode o servidor:
```bash
python app.py
```

4. Acesse no navegador: http://localhost:5000

## Deploy no PythonAnywhere

1. Crie uma conta gratuita em https://www.pythonanywhere.com
2. Vá em **Dashboard > Files** e faça upload do projeto (ou clone via GitHub)
3. Vá em **Web > Add a new web app**
4. Escolha **Flask** e **Python 3.x**
5. Em **Source code**, aponte para a pasta do projeto
6. Em **WSGI configuration file**, certifique-se que aponta para `app.py`
7. Clique em **Reload** e acesse seu site!

## Personalização

- Edite `templates/membros.html` para adicionar os membros reais do grupo
- Edite `templates/sobre.html` para atualizar a história e missão
- Edite `templates/contato.html` com os dados de contato reais
- Para ativar o formulário de contato, adicione uma rota POST no `app.py`
